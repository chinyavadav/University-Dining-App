<?php
include("connection.php");
if(isset($_GET["meal_id"])){        
	$meal_id = mysqli_real_escape_string($conn,$_GET["meal_id"]);
	$statement="DELETE FROM tblmenu WHERE fldmeal_id='$meal_id'";
	$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	$response['response']='success';
} else{
	$response=array("response"=>"failed");
}
echo json_encode($response);

?>