<?php
include("connection.php");
$data=array();

$statement="SELECT AVG(fldcost) FROM tblmeals WHERE fldtype='Lunch & Supper'";
$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
$averageLunchSupper=mysqli_fetch_assoc($query)['AVG(fldcost)'];
if($averageLunchSupper==null){
	$averageLunchSupper=0;
}

$statement="SELECT AVG(fldcost) FROM tblmeals WHERE fldtype='Breakfast'";
$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
$averageBreakfast=mysqli_fetch_assoc($query)['AVG(fldcost)'];
if($averageBreakfast==null){
	$averageBreakfast=0;
}

$data["averageLunchSupper"]=$averageLunchSupper;
$data["averageBreakfast"]=$averageBreakfast;

echo json_encode($data);   
?>