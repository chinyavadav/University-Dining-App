<?php
include("connection.php");
if(isset($_GET["regno"]) && isset($_GET["val"])){		
	$regno=mysqli_real_escape_string($conn,$_GET["regno"]);
	$val=mysqli_real_escape_string($conn,$_GET["val"]);
	$new_min=$val*100;
	$statement="UPDATE tblstudents SET fldlower_theshold='$new_min' WHERE fldregno='$regno'";
	$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	$response=array("response"=>"success");
	echo json_encode($response);	    
}

?>