<?php
include("connection.php");
$meals=array();
$date=date('Y-m-d');
$statement="SELECT * FROM tblmeals WHERE fldmeal_id NOT IN (SELECT fldmeal_id FROM tblmenu WHERE fldtimestamp LIKE '$date%')";
$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
while($record=mysqli_fetch_assoc($query)){          
    $meals[]=$record;
}
echo json_encode($meals);   
?>