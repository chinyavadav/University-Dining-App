<?php
    include("connection.php");
    $transactions=array();
    if(isset($_GET["regno"])){
        $regno=mysqli_real_escape_string($conn,$_GET["regno"]);
    	$statement="SELECT * FROM tbltransactions WHERE fldregno='$regno' ORDER BY fldtimestamp DESC LIMIT 0,50";
        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
        while($record=mysqli_fetch_assoc($query)){          
            $transactions[]=$record;
        }
    }
    echo json_encode($transactions);   
?>