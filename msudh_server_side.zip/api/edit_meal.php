<?php
	include("connection.php");
	header('Content-Type: application/json');
	if($_SERVER["REQUEST_METHOD"]=="POST"){		
	    $postdata = file_get_contents("php://input");
	    if (isset($postdata) && isset($_GET["meal_id"])) {
	        $request = json_decode($postdata);
	        $meal_id=mysqli_real_escape_string($conn,$_GET["meal_id"]);
	        $title=mysqli_real_escape_string($conn,$request->title);
	        $description=mysqli_real_escape_string($conn,$request->description);
	        $cost=mysqli_real_escape_string($conn,$request->cost);
	        $cost_in_cents=$cost*100;
	        $type=mysqli_real_escape_string($conn,$request->type);
	        $picture=$request->picture;

	        $statement="UPDATE tblmeals SET fldtitle='$title', flddescription='$description',fldcost='$cost_in_cents',fldtype='$type',fldpicture='$picture' WHERE fldmeal_id='$meal_id'";
	        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	        $qry=mysqli_query($conn,"SELECT LAST_INSERT_ID()") OR die(mysqli_error($conn));
	        $meal_id=mysqli_fetch_assoc($qry)["LAST_INSERT_ID()"];
	        $response=array("response"=>"success","meal_id"=>$meal_id);
		}else {
	        $response=array("response"=>"failed");
	    }
	    echo json_encode($response);	    
	}

	function failed(){
		$response=array("response"=>"failed");
		echo json_encode($response);
	}
?>