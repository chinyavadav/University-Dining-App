<?php
$username="chinyavadav";
$token="";
if(isset($_GET["to"]) && isset($_GET["msg"])){
	$to=$_GET["to"];
	$msg=$_GET["msg"]; 
	$baseURL="http://portal.bulksmsweb.com/index.php?app=ws&u=$username&h=$token&op=pv&to=$to&msg=$msg";
	
}
?>