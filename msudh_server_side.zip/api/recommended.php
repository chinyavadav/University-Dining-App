<?php
include("connection.php");
$meals=array();
if(isset($_GET["regno"])){        
	$regno = mysqli_real_escape_string($conn,$_GET["regno"]);
	$lastMeals=Array();
	$date=date("Y-m-d");
	
	$statement="SELECT DISTINCT(tbltransactions.flddescription) as x,tblmeals.fldmeal_id,tblmeals.fldtitle,tblmeals.flddescription,tblmeals.fldcost,tblmeals.fldtype,tblmeals.fldpicture FROM tbltransactions JOIN tblmeals ON tbltransactions.flddescription=tblmeals.fldtitle WHERE tblmeals.fldmeal_id IN (SELECT fldmeal_id FROM tblmenu WHERE fldtimestamp LIKE '$date%') and tbltransactions.fldregno='$regno' and tbltransactions.fldcredit!='0' and tbltransactions.flddescription NOT LIKE '%breakfast%'  ORDER BY tbltransactions.fldtransaction_id";
	$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	if(mysqli_num_rows($query)>0){
		while($record=mysqli_fetch_assoc($query)){
			unset($record["x"]);
			$lastMeals[]=$record;        
		}
	}

	$mealTypes=Array();
	$statement="SELECT * FROM tblmeals WHERE fldtype='Lunch & Supper' and fldmeal_id IN (SELECT fldmeal_id FROM tblmenu WHERE fldtimestamp LIKE '$date%')";
	$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	while($record=mysqli_fetch_assoc($query)){
		$mealTypes[]=$record;        
	}

	$temp=Array();
	foreach ($mealTypes as $key => $value) {
		if(!in_array($value,$lastMeals)){
			$temp[]=$value;
		}
	}
	$meals = array_merge($temp,$lastMeals);
}
echo json_encode($meals);   
?>