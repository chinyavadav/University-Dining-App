<?php
include("connection.php");
if($_SERVER["REQUEST_METHOD"]=="POST"){        
    $postdata = file_get_contents("php://input");
    if (isset($postdata)) {
        $request = json_decode($postdata);
        $regno=mysqli_real_escape_string($conn,$request->regno);
        $feedback = mysqli_real_escape_string($conn,$request->feedback);
        $time=date('Y-m-d H:i:s');
        $statement="INSERT INTO tblfeedback(fldregno,fldmessage,fldtimestamp) VALUES ('$regno','$feedback','$time')";
        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
        $response['response']='success';
    } else{
        $response=array("response"=>"failed");
    }
    echo json_encode($response);
}
?>