<?php
    include("connection.php");
    if($_SERVER["REQUEST_METHOD"]=="POST"){        
        $postdata = file_get_contents("php://input");
        if (isset($postdata)) {
            $request = json_decode($postdata);
            $regno = mysqli_real_escape_string($conn,$request->regno);
            $password =mysqli_real_escape_string($conn,$request->password);

            $statement="SELECT * FROM tblstudents WHERE fldregno='$regno' and fldpassword=MD5('$password') LIMIT 0,1";
            $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
            if(mysqli_num_rows($query)==1){
                $response=mysqli_fetch_assoc($query);
                $response['response']='success';
            }else{
                $response=array("response"=>"failed");
            }
        } else{
            $response=array("response"=>"failed");
        }
        echo json_encode($response);
    }
?>