<?php
include("connection.php");
if(isset($_GET["meal_id"])){        
	$meal_id = mysqli_real_escape_string($conn,$_GET["meal_id"]);
	$date=date('Y-m-d H:i:s');
	$statement="INSERT INTO tblmenu VALUES('$meal_id','$date')";
	$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	$response['response']='success';
} else{
	$response=array("response"=>"failed");
}
echo json_encode($response);

?>