<?php
include("connection.php");
$feedbacks=array();
$date=date('Y-m-d');
$statement="SELECT * FROM tblfeedback ORDER BY fldtimestamp DESC";
//WHERE fldtimestamp LIKE '$date%'
$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
while($record=mysqli_fetch_assoc($query)){          
    $feedbacks[]=$record;
}
echo json_encode($feedbacks);   
?>