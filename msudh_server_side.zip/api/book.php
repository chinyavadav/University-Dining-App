<?php
include("connection.php");
if(isset($_GET["regno"]) && isset($_GET["meal_id"])){		
	$regno=mysqli_real_escape_string($conn,$_GET["regno"]);
	$meal_id=mysqli_real_escape_string($conn,$_GET["meal_id"]);
	$date=date('Y-m-d H:i:s');

	$statement="DELETE FROM tblbookings WHERE fldregno='$regno'";
	$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));

	$statement="INSERT INTO tblbookings VALUES('$regno','$meal_id','$date')";
	$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	$response=array("response"=>"success");
	echo json_encode($response);	    
}

?>