<!------ Include the above in your HEAD tag ---------->
<?php
include("api/connection.php");
$upnext=Array();
$qry=mysqli_query($conn,"SELECT  tblbookings.fldregno,tblmeals.fldtitle FROM tblbookings JOIN tblmeals ON tblbookings.fldmeal_id=tblmeals.fldmeal_id  ORDER BY fldtimestamp DESC") or die(mysqli_error($conn));
while($record=mysqli_fetch_assoc($qry)){
  $upnext[]=$record;
}
?>
<!DOCTYPE html>
<html>

<head>
  <title>Midlands State University</title>
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>
<!--Coded with love by Mutiullah Samim-->
<body>
  <div class="card">
    <h3 class="card-header text-center font-weight-bold text-uppercase py-4">MSU Dining Bookings</h3>
    <div class="card-body">
      <div id="table" class="table-editable">
        <span class="table-add float-right mb-3 mr-2">
          <a href="#!" class="text-success">
            <i class="fas fa-plus fa-2x" aria-hidden="true"></i>
          </a>
        </span>
        <table class="table table-bordered table-responsive-md table-striped text-center">
          <thead>
            <tr>
              <th class="text-center">Position #</th>
              <th class="text-center">Reg No</th>
              <th class="text-center">Meal</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $count=1;
            foreach ($upnext as $key => $value) {
              ?>
              <tr>
                <td class="pt-3-half" contenteditable="true"><?php echo $count; ?></td>
                <td class="pt-3-half" contenteditable="true"><?php echo $value['fldregno']; ?></td>
                <td class="pt-3-half" contenteditable="true"><?php echo $value['fldtitle']; ?></td>
              </tr>
              <?php     
              $count++;           
            }
            ?>
            <!-- This is our clonable table line -->
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <!-- Editable table -->
</body>
</html>
