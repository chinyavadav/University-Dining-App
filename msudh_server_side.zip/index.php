<!------ Include the above in your HEAD tag ---------->
<?php
include("api/connection.php");
if($_SERVER["REQUEST_METHOD"]=="POST"){        
	$regno = mysqli_real_escape_string($conn,$_POST["txtregno"]);
	$meal_id =mysqli_real_escape_string($conn,$_POST["cbomeal"]);
	$date=date('Y-m-d H:i:s');
	$statement="SELECT * FROM tblmeals WHERE fldmeal_id='$meal_id'";
	$qry=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	if(mysqli_num_rows($qry)==1){
		$record=mysqli_fetch_assoc($qry);
		$stmt="INSERT INTO tbltransactions(fldregno,flddescription,flddebit,fldcredit,fldtimestamp) VALUES('$regno','$record[fldtitle]','0','$record[fldcost]','$date')";
		$query=mysqli_query($conn,$stmt) or die(failed());
		$stmt1="UPDATE tblstudents SET fldbalance=fldbalance-$record[fldcost] WHERE fldregno='$regno'";
		$query1=mysqli_query($conn,$stmt1) or die(failed());
		$stmt2="SELECT * FROM tblstudents WHERE fldregno='$regno'";
		$query2=mysqli_query($conn,$stmt2) or die(failed());
		echo "<script>alert('Transaction Successful');window.location='index.php';</script>";
		if(mysqli_num_rows($query2)==1){
			$record=mysqli_fetch_assoc($query2);
			if($record["fldbalance"]<$record["fldlower_theshold"]){
				sendSMS();
			}
		}
	}
}

if(isset($_GET["remove"])){
	$remove=mysqli_real_escape_string($conn,$_GET["remove"]);
	$statement="DELETE FROM tblbookings WHERE fldregno='$remove'";
	$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	echo "<script>alert('Student successfully removed from list!');window.location='index.php';</script>";
}elseif(isset($_GET["skip"])){
	$skip=mysqli_real_escape_string($conn,$_GET["skip"]);
	$date=date('Y-m-d H:i:s');
	$statement="UPDATE tblbookings SET fldtimestamp='$date' WHERE fldregno='$skip'";
	$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	echo "<script>alert('Student successfully skip and placed at the back of the list!');window.location='index.php';</script>";
}

$upnext=Array();
$qry=mysqli_query($conn,"SELECT tblbookings.fldregno,tblbookings.fldmeal_id,tblstudents.fldforename,tblstudents.fldsurname FROM tblbookings JOIN tblstudents ON tblbookings.fldregno=tblstudents.fldregno ORDER BY fldtimestamp DESC LIMIT 0,10") or die(mysqli_error($conn));
while($record=mysqli_fetch_assoc($qry)){
	$upnext[]=$record;
}

function failed(){
	echo "<script>alert('Failed to transact! Wrong Reg No');window.location='index.php';</script>";
}

function sendSMS(){
	$message="Your Gold Card account has depleted below set theshold. Please Topup your account!";
	$url="http://portal.bulksmsweb.com/index.php?app=ws&u=chinyavadav&h=3b51bb12e67aff427b32077c55b20b55&op=pv&to=0782135087&msg=$message";
	$cSession = curl_init(); 
	curl_setopt($cSession,CURLOPT_URL,$url);
	curl_setopt($cSession,CURLOPT_RETURNTRANSFER,true);
	curl_setopt($cSession,CURLOPT_HEADER, false); 
	$result=curl_exec($cSession);
	curl_close($cSession);
	echo $result;
}
?>
<!DOCTYPE html>
<html>

<head>
	<title>Midlands State University</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.1/css/all.css" integrity="sha384-gfdkjb5BdAXd+lj+gudLWI+BXq4IuLW5IT+brZEZsLFm++aCMlF1V92rMkPaX4PP" crossorigin="anonymous">
	<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
	<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
	<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>
<!--Coded with love by Mutiullah Samim-->
<body>
	<style type="text/css">
		/* Coded with love by Mutiullah Samim */
		body,
		html {
			margin: 0;
			padding: 0;
			height: 100%;
			background: #60a3bc !important;
		}
		.user_card {
			height: 400px;
			width: 350px;
			margin-top: auto;
			margin-bottom: auto;
			background: #f39c12;
			position: relative;
			display: flex;
			justify-content: center;
			flex-direction: column;
			padding: 10px;
			box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
			-webkit-box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
			-moz-box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
			border-radius: 5px;

		}
		.brand_logo_container {
			position: absolute;
			height: 170px;
			width: 170px;
			top: -75px;
			border-radius: 50%;
			background: #60a3bc;
			padding: 10px;
			text-align: center;
		}
		.brand_logo {
			height: 150px;
			width: 150px;
			border-radius: 50%;
			border: 2px solid white;
		}
		.form_container {
			margin-top: 100px;
		}
		.login_btn {
			width: 100%;
			background: #c0392b !important;
			color: white !important;
		}
		.login_btn:focus {
			box-shadow: none !important;
			outline: 0px !important;
		}
		.login_container {
			padding: 0 2rem;
		}
		.input-group-text {
			background: #c0392b !important;
			color: white !important;
			border: 0 !important;
			border-radius: 0.25rem 0 0 0.25rem !important;
		}
		.input_user,
		.input_pass:focus {
			box-shadow: none !important;
			outline: 0px !important;
		}
		.custom-checkbox .custom-control-input:checked~.custom-control-label::before {
			background-color: #c0392b !important;
		}
	</style>
	<nav class="navbar navbar-inverse">
		<div class="container-fluid">
			<a href="?remove=<?php if(isset($upnext[0])){ echo $upnext[0]['fldregno']; }  ?>" class="btn btn-danger navbar-btn pull-left">Remove</a>
			<a href="?skip=<?php if(isset($upnext[0])){echo $upnext[0]['fldregno']; } ?>" class="btn btn-danger navbar-btn pull-right">Skip</a>
		</div>
	</nav>
	<div class="container h-100">
		<div class="d-flex justify-content-center h-100">
			<div class="user_card">
				<div class="d-flex justify-content-center">
					<div class="brand_logo_container">
						<img src="logo.jpg" class="brand_logo" alt="Logo">
					</div>
				</div>
				<div class="d-flex justify-content-center form_container">
					<form method="post" action="">
						<div class="input-group mb-3">
							<div class="input-group-append">
								<span class="input-group-text"><i class="fas fa-user"></i></span>
							</div>
							<input type="text" readonly name="txtregno" value="<?php if(isset($upnext[0])){echo $upnext[0]['fldregno'];} ?>" required="" class="form-control input_user" placeholder="Reg Number">
						</div>
						<div class="input-group mb-2">
							<div class="input-group-append">
								<span class="input-group-text"><i class="fas fa-key"></i></span>
							</div>
							<select name="cbomeal" class="form-control">
								<?php
								$qry=mysqli_query($conn,"SELECT fldmeal_id,fldtitle FROM tblmeals") or die(mysqli_error($conn));
								while($record=mysqli_fetch_assoc($qry)){
									$selected="";
									if($upnext[0]['fldmeal_id']==$record['fldmeal_id']){
										$selected="selected";
									}
									echo "<option $selected value='$record[fldmeal_id]'>$record[fldtitle]</option>";
								}
								?>
							</select>
						</div>
						<div class="d-flex justify-content-center mt-3 login_container">
							<button type="submit" name="button" class="btn btn-block login_btn">Transact</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</body>
</html>
